// SCORM 1.2 API Wrapper
var API = null;
var _initialized = false;

function findAPI(win) {
  var findAPITries = 0;
  while (win.API == null && win.parent != null && win.parent != win) {
    findAPITries++;
    if (findAPITries > 7) return null;
    win = win.parent;
  }
  return win.API;
}

function getAPI() {
  var theAPI = findAPI(window);
  if (theAPI == null && window.opener != null && typeof window.opener != 'undefined') {
    theAPI = findAPI(window.opener);
  }
  return theAPI;
}

function scormInit() {
  API = getAPI();
  if (API == null) return false;
  var result = API.LMSInitialize('');
  _initialized = (result.toString() === 'true' || result === true);
  return _initialized;
}

function scormSetValue(key, val) {
  if (API == null || !_initialized) return;
  API.LMSSetValue(key, val.toString());
}

function scormCommit() {
  if (API == null || !_initialized) return;
  API.LMSCommit('');
}

function scormFinish() {
  if (API == null || !_initialized) return;
  API.LMSFinish('');
}

function scormReportScore(pct) {
  if (API == null || !_initialized) return;
  scormSetValue('cmi.core.score.min', '0');
  scormSetValue('cmi.core.score.max', '100');
  scormSetValue('cmi.core.score.raw', pct.toString());
  scormSetValue('cmi.core.lesson_status', pct >= 70 ? 'passed' : 'failed');
  scormSetValue('cmi.core.exit', 'normal');
  scormCommit();
}

// Auto-init and finish
window.addEventListener('load', function() { scormInit(); });
window.addEventListener('beforeunload', function() { scormFinish(); });
